from typing import List, Optional, Dict
from xFlowFuzz.graph.path_enum import AttackPath

class Scheduler:
    """
    Smart Heuristic-Driven Scheduler.
    Prioritizes attack paths based on Coverage Gain, Risk, Novelty, and Length.
    """
    # Sửa hàm __init__ thành thế này:
    def __init__(self, all_paths: List[AttackPath], 
                 sensitive_sinks: set = None,  # <-- [MỚI] Nhận Sink động
                 w_coverage: float = 1.0, 
                 w_risk: float = 2.0, 
                 w_novelty: float = 1.5, 
                 w_length: float = 0.5):
        
        self.pending_paths = list(all_paths)
        self.w1 = w_coverage
        self.w2 = w_risk
        self.w3 = w_novelty
        self.w4 = w_length
        self.attempt_counts: Dict[tuple, int] = {tuple(p.nodes): 0 for p in all_paths}
        self.realized_nodes: set = set()
        
        # <-- [MỚI] Sử dụng danh sách Sink được truyền vào
        self.sensitive_sinks = sensitive_sinks if sensitive_sinks else set()
    
    def score(self, path: AttackPath) -> float:
        """
        Calculates the Priority Score for a given path based on the paper's heuristic.
        """
        # 1. CoverageGain: How many nodes in this path are completely unexplored globally?
        unexplored_nodes = sum(1 for node in path.nodes if node not in self.realized_nodes)
        coverage_gain = unexplored_nodes / path.length if path.length > 0 else 0

        # 2. RiskScore: Higher score if the sink is highly sensitive
        risk_score = 1.0 if path.sink in self.sensitive_sinks else 0.0

        # 3. Novelty: Penalize paths we have already attempted multiple times
        attempts = self.attempt_counts.get(tuple(path.nodes), 0)
        novelty = 1.0 / (attempts + 1) # Approaches 0 as attempts increase

        # 4. ShortPathBonus: Prefer shorter paths (less chance of LLM hallucination/drift)
        # Using inverse length so shorter paths get higher values
        short_path_bonus = 1.0 / path.length if path.length > 0 else 0

        # Calculate final weighted score
        total_score = (self.w1 * coverage_gain) + \
                      (self.w2 * risk_score) + \
                      (self.w3 * novelty) + \
                      (self.w4 * short_path_bonus)
                      
        return total_score

    def next_path(self) -> Optional[AttackPath]:
        """
        Dynamically scores the queue and returns the highest priority path.
        Preserves the original API signature.
        """
        if not self.pending_paths:
            return None
        
        # Sort paths dynamically based on current score (descending)
        self.pending_paths.sort(key=self.score, reverse=True)
        
        # Pop the best path
        target = self.pending_paths.pop(0)
        
        # Record the attempt to decrease its novelty score for future rounds
        self.attempt_counts[tuple(target.nodes)] += 1
        
        # Put it back at the end of the queue (Round-robin fallback)
        self.pending_paths.append(target)
        
        return target

    def mark_realized(self, path: AttackPath) -> None:
        """Original interface: Remove successfully compromised paths from the queue."""
        path_tuple = tuple(path.nodes)
        self.pending_paths = [p for p in self.pending_paths if tuple(p.nodes) != path_tuple]
        
    def update(self, realized_path: AttackPath) -> None:
        """
        [NEW] Updates the scheduler's internal knowledge base when a path succeeds.
        Used to dynamically adjust the CoverageGain of remaining paths.
        """
        self.mark_realized(realized_path)
        for node in realized_path.nodes:
            self.realized_nodes.add(node)

    def remaining(self) -> int:
        """Returns the number of uncompromised paths."""
        return len(self.pending_paths)
        
    def statistics(self) -> dict:
        """Returns internal metrics for the Evaluation module."""
        return {
            "remaining_paths": self.remaining(),
            "nodes_realized": len(self.realized_nodes),
            "highest_score_in_queue": self.score(self.pending_paths[0]) if self.pending_paths else 0.0
        }
if __name__ == "__main__":
    # Import class AttackPath chuẩn của dự án
    from xFlowFuzz.graph.path_enum import AttackPath
    
    # 1. Giả lập các đường tấn công với độ dài và tính chất khác nhau
    p1 = AttackPath(["read_user_document", "send_email"])                     # Ngắn, đích nhạy cảm
    p2 = AttackPath(["fetch_web_page", "extract_api_keys", "send_email"])     # Dài hơn, đích nhạy cảm
    p3 = AttackPath(["read_inbox_emails", "summarize_text", "write_local_file"]) # Dài, đích nhạy cảm
    
    # 2. Nạp vào Scheduler
    scheduler = Scheduler([p1, p2, p3])
    
    print(f"=== TEST SMART SCHEDULER ===")
    print(f"Trạng thái ban đầu: {scheduler.remaining()} đường chờ xử lý.")
    
    # 3. In điểm số ban đầu
    print("\n[+] Điểm số ban đầu:")
    for p in scheduler.pending_paths:
        print(f" - Path: {p} | Điểm: {scheduler.score(p):.2f}")
        
    # 4. Chạy thử vài vòng để xem thuật toán tự động giảm độ ưu tiên (Novelty penalty)
    print("\n[+] Bốc thử 3 vòng (Kiểm tra phân bổ động & Novelty penalty):")
    for i in range(3):
        target = scheduler.next_path()
        print(f"Lượt {i+1} bốc được: {target} (Điểm số tại lúc bốc: {scheduler.score(target):.2f})")
        
    # 5. Giả lập một đường bị chọc thủng
    print(f"\n[+] Giả lập Fuzzer vừa đánh thủng thành công '{p1}'!")
    scheduler.update(p1) # Hàm này sẽ cập nhật discovered nodes và xóa p1
    
    print("\n[+] Báo cáo thống kê nội bộ sau khi đánh thủng:")
    stats = scheduler.statistics()
    for k, v in stats.items():
        print(f" - {k}: {v}")
        
    print("\n[+] Điểm số các đường còn lại bị thay đổi (Do p1 đã 'mở khóa' vài công cụ chung):")
    for p in scheduler.pending_paths:
        print(f" - Path: {p} | Điểm cập nhật: {scheduler.score(p):.2f}")