"""Generic tool-calling agent loop for XFlowFuzz.

The runner is provider-neutral. Any OpenAI/Anthropic/local adapter only needs
to implement the LLMClient protocol and return LLMResponse objects.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field, is_dataclass
import json
import time
from typing import Any, Protocol, Sequence

from .tool_executor import ToolExecutor
from .trace import ExecutionTrace, TraceRecorder


@dataclass(slots=True)
class ToolCall:
    """Normalized tool call returned by an LLM adapter."""

    name: str
    arguments: dict[str, Any]
    call_id: str | None = None


@dataclass(slots=True)
class LLMResponse:
    """Provider-neutral LLM response."""

    content: str | None = None
    tool_calls: list[ToolCall] = field(default_factory=list)
    raw: Any = None
    input_tokens: int | None = None
    output_tokens: int | None = None


class LLMClient(Protocol):
    """Minimal interface required by AgentRunner."""

    def complete(
        self,
        *,
        messages: Sequence[dict[str, Any]],
        tools: Sequence[dict[str, Any]],
    ) -> LLMResponse:
        ...


@dataclass(slots=True)
class ToolExecutionResult:
    """Normalized result of one realized tool call."""

    tool_name: str
    arguments: dict[str, Any]
    output: Any
    call_id: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "tool_name": self.tool_name,
            "arguments": _json_safe(self.arguments),
            "output": _json_safe(self.output),
            "call_id": self.call_id,
        }


@dataclass(slots=True)
class AgentRunResult:
    """Stable contract shared with fuzzing and evaluation modules."""

    prompt: str
    final_response: str | None
    trace: ExecutionTrace
    messages: list[dict[str, Any]]
    llm_calls: int
    stopped_reason: str
    elapsed_s: float
    input_tokens: int = 0
    output_tokens: int = 0
    tool_results: list[ToolExecutionResult] = field(default_factory=list)
    witnesses: list[Any] = field(default_factory=list)

    @property
    def execution_path(self) -> list[str]:
        """All successfully executed tools (control-flow trace)."""
        return self.trace.realized_path()

    @property
    def realized_taint_paths(self) -> list[list[str]]:
        """Confirmed source-to-sink paths carrying a taint label."""
        paths: list[list[str]] = []
        seen: set[tuple[str, ...]] = set()
        for witness in self.witnesses:
            path = tuple(getattr(witness, "path", ()) or ())
            if path and path not in seen:
                seen.add(path)
                paths.append(list(path))
        return paths

    @property
    def realized_path(self) -> list[str]:
        """Compatibility alias: first confirmed taint path, else execution path."""
        return self.realized_taint_paths[0] if self.realized_taint_paths else self.execution_path

    @property
    def success(self) -> bool:
        return not self.stopped_reason.startswith("error:")

    @property
    def leak_detected(self) -> bool:
        return bool(self.witnesses)

    def to_dict(self) -> dict[str, Any]:
        return {
            "prompt": self.prompt,
            "final_response": self.final_response,
            "trace": self.trace.to_dict(),
            "messages": _json_safe(self.messages),
            "llm_calls": self.llm_calls,
            "stopped_reason": self.stopped_reason,
            "elapsed_s": self.elapsed_s,
            "input_tokens": self.input_tokens,
            "output_tokens": self.output_tokens,
            "execution_path": self.execution_path,
            "realized_path": self.realized_path,
            "realized_taint_paths": self.realized_taint_paths,
            "success": self.success,
            "leak_detected": self.leak_detected,
            "tool_results": [item.to_dict() for item in self.tool_results],
            "witnesses": [_json_safe(item) for item in self.witnesses],
        }


class AgentRunner:
    """Run an LLM agent until it answers, errors or reaches the step limit."""

    def __init__(
        self,
        llm: LLMClient,
        executor: ToolExecutor,
        *,
        max_steps: int = 8,
        system_prompt: str | None = None,
    ) -> None:
        if max_steps < 1:
            raise ValueError("max_steps must be at least 1.")

        self.llm = llm
        self.executor = executor
        self.max_steps = max_steps
        self.system_prompt = system_prompt

    def run(
        self,
        prompt: str,
        *,
        metadata: dict[str, Any] | None = None,
    ) -> AgentRunResult:
        if not prompt.strip():
            raise ValueError("Prompt cannot be empty.")

        self.executor.reset_taint()
        reset_llm = getattr(self.llm, "reset", None)
        if callable(reset_llm):
            reset_llm()

        trace = ExecutionTrace(metadata=dict(metadata or {}))
        recorder = TraceRecorder(trace)
        previous_recorder = self.executor.trace_recorder
        self.executor.set_trace_recorder(recorder)

        messages: list[dict[str, Any]] = []
        if self.system_prompt:
            messages.append({"role": "system", "content": self.system_prompt})
        messages.append({"role": "user", "content": prompt})

        final_response: str | None = None
        stopped_reason = "max_steps"
        llm_calls = 0
        input_tokens = 0
        output_tokens = 0
        tool_results: list[ToolExecutionResult] = []
        started = time.perf_counter()

        try:
            for _ in range(self.max_steps):
                response = self.llm.complete(
                    messages=messages,
                    tools=self.executor.describe_tools(),
                )
                llm_calls += 1
                input_tokens += response.input_tokens or 0
                output_tokens += response.output_tokens or 0

                messages.append(self._assistant_message(response))

                if not response.tool_calls:
                    final_response = response.content
                    stopped_reason = "final_response"
                    break

                for tool_call in response.tool_calls:
                    output = self.executor.execute(
                        tool_call.name,
                        tool_call.arguments,
                        call_id=tool_call.call_id,
                    )
                    tool_results.append(
                        ToolExecutionResult(
                            tool_name=tool_call.name,
                            arguments=dict(tool_call.arguments),
                            output=output,
                            call_id=tool_call.call_id,
                        )
                    )
                    messages.append(self._tool_message(tool_call, output))
            else:
                stopped_reason = "max_steps"

        except Exception as exc:
            stopped_reason = f"error:{type(exc).__name__}"
            final_response = str(exc)
        finally:
            recorder.finish()
            self.executor.set_trace_recorder(previous_recorder)

        raw_witnesses = self.executor.get_witnesses()
        witnesses = [
            witness.with_run(trace.run_id)
            if hasattr(witness, "with_run") else witness
            for witness in raw_witnesses
        ]

        return AgentRunResult(
            prompt=prompt,
            final_response=final_response,
            trace=trace,
            messages=messages,
            llm_calls=llm_calls,
            stopped_reason=stopped_reason,
            elapsed_s=time.perf_counter() - started,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            tool_results=tool_results,
            witnesses=witnesses,
        )

    @staticmethod
    def _assistant_message(response: LLMResponse) -> dict[str, Any]:
        message: dict[str, Any] = {
            "role": "assistant",
            "content": response.content or "",
        }

        if response.tool_calls:
            message["tool_calls"] = [
                {
                    "id": call.call_id,
                    "name": call.name,
                    "arguments": dict(call.arguments),
                }
                for call in response.tool_calls
            ]

        return message

    @staticmethod
    def _tool_message(tool_call: ToolCall, output: Any) -> dict[str, Any]:
        return {
            "role": "tool",
            "tool_call_id": tool_call.call_id,
            "name": tool_call.name,
            "content": _serialize_tool_output(output),
        }


def _serialize_tool_output(output: Any) -> str:
    if isinstance(output, str):
        return output

    try:
        return json.dumps(_json_safe(output), ensure_ascii=False)
    except (TypeError, ValueError):
        return str(output)


def _json_safe(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if is_dataclass(value):
        return _json_safe(asdict(value))
    if hasattr(value, "to_dict"):
        try:
            return _json_safe(value.to_dict())
        except Exception:
            return str(value)
    if isinstance(value, dict):
        return {str(key): _json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple, set, frozenset)):
        return [_json_safe(item) for item in value]
    return str(value)
